// Replace these with your AWS Cognito settings
const AWS_REGION = 'REGION-CODE';
const USER_POOL_ID = 'COGNITO-USER-POOl_ID';
const CLIENT_ID = 'COGNITO-USER-CLIENT_ID';
const api_endpoint = 'API-ENDPOINT'

const authData = {
  UserPoolId: USER_POOL_ID,
  ClientId: CLIENT_ID,
};

const userPool = new AmazonCognitoIdentity.CognitoUserPool(authData);

// Verification
document.getElementById('verify-button').addEventListener('click', async function() {
  var verificationCode = document.getElementById('verification-code').value;
  var email = document.getElementById('register-email').value;
  var username = document.getElementById('register-username').value;

  var userData = {
      Username: username,
      email,
      Pool: userPool
  };

  var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

  await cognitoUser.confirmRegistration(verificationCode, true, function(err, result) {
    console.log(result)
      if (err) {
          console.log(err.message);
      } else {
          console.log('Verification successful. You can now log in.');
          registerContainer.style.display = 'none';
          signinContainer.style.display = 'block';
      }
  });
});

const FetchDataAPI = () => {
    // User is logged in, call your API
    const apiEndpoint = api_endpoint;
      
    fetch(apiEndpoint)
      .then((response) => {
        console.log(response)
        return response.json()
      })
      .then((data) => {
        console.log(data.body)
        const tableBody = document.getElementById('employee-table-body');
        tableBody.innerHTML='';
        data.body.forEach((employee) => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${employee.empid.S}</td>
            <td>${employee.empfirstname.S}</td>
            <td>${employee.emplastname.S}</td>
            <td>${employee.empage.S}</td>
          `;
          tableBody.appendChild(row);
        });
      })
      .catch((error) => {
        console.error('Error fetching data from the API:', error);
      });
}

document.addEventListener('DOMContentLoaded', function () {
  const signInButton = document.getElementById('sign-in-button');
  const signOutButton = document.getElementById('sign-out-button');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const userContainer = document.getElementById('user-info');
  const errorElement = document.getElementById('error-message');
  const profileContainer = document.getElementById('profile-container');
  const signOutDiv = document.getElementById('sign-out');
  const getEmpDataBtn = document.getElementById('get-emp-data-btn');
  const empTable = document.getElementById('employee-table');
  const signinContainer = document.getElementById('signin-container');

  getEmpDataBtn.addEventListener('click', function(){
    getTableData()
    empTable.style.display = 'block';
    // getEmpDataBtn.style.display = 'none';
  })

  const authenticateUser = (username, password) => {
    const authenticationData = {
      Username: username,
      Password: password,
    };

    const authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);

    const userData = {
      Username: username,
      Pool: userPool,
    };

    const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    const changePassword = (newPassword) => {
        cognitoUser.completeNewPasswordChallenge(newPassword, {}, {
          onSuccess: (session) => {
            console.log('Password change successful', session);
            document.getElementById('new-password').style.display = 'none';
            document.getElementById('change-password-button').style.display = 'none';
            errorElement.textContent = 'Password changed successfully.';
          },
          onFailure: (err) => {
            console.error('Password change failed', err);
            errorElement.textContent = 'Password change failed. Please try again.';
          },
        });
      };

    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: (session) => {
        console.log('Authentication successful', session);
        userContainer.textContent = cognitoUser.getUsername();
        signInButton.style.display = 'none';
        signinContainer.style.display = 'none';
        signOutButton.style.display = 'block';
        errorElement.textContent = '';
        signOutDiv.style.display = 'block';

        // Show the protected profile container
        profileContainer.style.display = 'block';
      },
      onFailure: (err) => {
        console.error('Authentication failed', err);
        errorElement.textContent = 'Authentication failed. Please check your username and password.';
      },
      newPasswordRequired: (userAttributes, requiredAttributes) => {
        console.log('inside change password1')
        // User must set a new password
        console.log('Password change required');
        // Show the new password input and change password button
        document.getElementById('new-password').style.display = 'block';
        document.getElementById('change-password-button').style.display = 'block';

        // Add an event listener to the change password button
        document.getElementById('change-password-button').addEventListener('click', () => {
          console.log('inside change password2')
          const newPassword = document.getElementById('new-password').value;
          // Call a function to change the password with the new password
          changePassword(newPassword);
        });
        // You can handle password change here if needed
      },
    });
  };

  const signOut = () => {
    const cognitoUser = userPool.getCurrentUser();
    if (cognitoUser) {
      cognitoUser.signOut();
      userContainer.textContent = '';
      signInButton.style.display = 'block';
      signOutButton.style.display = 'none';
      errorElement.textContent = '';
      // Hide the protected profile container on sign-out
      profileContainer.style.display = 'none';
    }
  };

  signInButton.addEventListener('click', () => {
    const username = usernameInput.value;
    const password = passwordInput.value;

    if (username && password) {
      authenticateUser(username, password);
    } else {
      errorElement.textContent = 'Please provide both username and password.';
    }
  });

  signOutButton.addEventListener('click', () => {
    signOut();
  });

  const getTableData = () => {
    const cognitoUser = userPool.getCurrentUser();
    if (cognitoUser) {
        FetchDataAPI()
    }
}
});


document.getElementById('update-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const empid = document.getElementById('empid').value;
    const empfirstname = document.getElementById('empfirstname').value;
    const emplastname = document.getElementById('emplastname').value;
    const empage = document.getElementById('empage').value;

    // Create an object with the data
    const data = {
        empid,
        empfirstname,
        emplastname,
        empage
    };

    // Make the PUT request to your API
    fetch(api_endpoint, {
        method: 'POST',
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        document.getElementById('response').innerHTML = 'Data updated successfully';
        FetchDataAPI()
    })
    .catch(error => {
      console.log(error)
        document.getElementById('response').innerHTML = 'Error updating data: ' + error.message;
    });
});


const registerButton = document.getElementById('register-button');
const registerUsernameInput = document.getElementById('register-username');
const registerEmailInput = document.getElementById('register-email');
const registerPasswordInput = document.getElementById('register-password');
const registerErrorElement = document.getElementById('register-error-message');
const registerContainer = document.getElementById('register-container');
const signinContainer = document.getElementById('signin-container');
const loginRedirect = document.getElementById('login-redirect');
const registerRedirect = document.getElementById('register-redirect');


const registerUser = (username, email, password) => {
    console.log(username, email, password);
    const attributeList = [];

    // You can add more attributes here if needed
    const dataEmail = {
        Name: 'email',
        Value: email,
    };
    attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail));

    userPool.signUp(username, password, attributeList, null, (err, result) => {
        if (err) {
            console.error('Registration failed:', err);
            registerErrorElement.textContent = 'Registration failed. ' + err.message;
            return;
        }
        console.log('Registration successful:', result.user);
		document.getElementById('register-error-message').textContent = 'Registration successful. '
        // Handle successful registration here, e.g., show a confirmation message.
    });
};

registerButton.addEventListener('click', () => {
    const username = registerUsernameInput.value;
    const email = registerEmailInput.value;
    const password = registerPasswordInput.value;

    if (username && email && password) {
        registerUser(username, email, password);
    } else {
        registerErrorElement.textContent = 'Please provide all registration details.';
    }
});

loginRedirect.addEventListener('click', () => {
    registerContainer.style.display = 'none';
    signinContainer.style.display = 'block';
})

registerRedirect.addEventListener('click', () => {
    registerContainer.style.display = 'block';
    signinContainer.style.display = 'none';
})


// ... Your existing code ...

// Function to send a verification code to the user's email
const sendVerificationCode = (username) => {
  // Your existing code for sending the verification code
  // ...

  cognitoUser.forgotPassword({
      onSuccess: (data) => {
          console.log('Verification code sent successfully:', data);
          // Show the verification code input field
          document.getElementById('verification-container').style.display = 'block';
      },
      onFailure: (err) => {
          console.error('Error sending verification code:', err);
          // Handle the error and show an error message to the user
          document.getElementById('register-error-message').textContent = 'Error sending verification code: ' + err.message;
      },
  });
};

const confirmUser = (username, verificationCode) => {
  // Your existing code for confirming the user
  // ...

  var email = document.getElementById('register-email').value;
  var newPassword = document.getElementById('register-password').value;

  var userData = {
      Username: username,
      email,
      Pool: userPool
  };

  var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  console.log(cognitoUser)

  cognitoUser.confirmPassword(verificationCode, newPassword, {
      onSuccess: () => {
          console.log('User confirmed successfully');
          // Add code to allow the user to sign in after confirmation
          // You can redirect the user to the sign-in page or update the UI accordingly
      },
      onFailure: (err) => {
          console.error('User confirmation failed:', err);
          // Handle the error and show an error message to the user
          document.getElementById('register-error-message').textContent = 'User confirmation failed: ' + err.message;
      },
  });
};